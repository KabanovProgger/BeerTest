//
//  BreweryEntity+CoreDataClass.swift
//  BeerTest
//
//  Created by Owner on 8/13/24.
//
//

import Foundation
import CoreData


public class BreweryEntity: NSManagedObject {

}
